package Progetto;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JPanel;

public class CalcolateOraData  extends JPanel implements Runnable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Thread t,t1;
	
	public CalcolateOraData() {
		t = new Thread(this);
		t.start();
	}
	@Override
	public void run() {
		 t1 = Thread.currentThread();
		    while(t1 == t)
		    {
		        repaint();

		      try
		      {
		        // il metodo sleep() viene utilizzato per settare intervalli
		        // da un minuto prima che repaint() ricostruisca l'orologio
		        // aggiornando la data
		        t1.sleep(1000); 
		      }
		      catch(InterruptedException e){}
		    }

	}
	
	protected void paintComponent(Graphics g) {
        super.paintComponent(g);
		Calendar cal = new GregorianCalendar();
		Graphics2D g2 = (Graphics2D) g;
	    // Vengono valorizzate le variabili
	    String ore = String.valueOf(cal.get(Calendar.HOUR_OF_DAY));
	    String minuti = String.valueOf(cal.get(Calendar.MINUTE));
	    String giorno = String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
	    int month = cal.get(Calendar.MONTH);
	    String mese = String.valueOf(month);
	    int m = Integer.parseInt(mese)+1;
	    String anno = String.valueOf(cal.get(Calendar.YEAR));
	    String numeroGiorno = String.valueOf(cal.get(Calendar.DAY_OF_WEEK));
	    String nomeGiorno = ConvertNumToString(numeroGiorno);
	    /*Stampo la data*/
	    Font font = new Font("Arial", Font.BOLD,50);
	    g2.setFont(font);
	    g2.drawString(ore, 200, 200);
	    font = new Font("Arial", Font.PLAIN,30);
	    g2.setFont(font);
	    g2.drawString(nomeGiorno+" "+giorno+"."+m+"."+anno, 100, 300);
	    font = new Font("Arial", Font.BOLD,50);
	    g2.setFont(font);
	    g2.drawString(minuti, 200, 400);
	}
	
	private String ConvertNumToString(String numeroGiorno) {
		String giorno = null;
		
		switch(numeroGiorno) {
		   case "1":
			   giorno = "Domenica";
			   break;
		   case "2":
			   giorno = "Lunedi";
			   break;
		   case "3":
			   giorno = "Martedi";
			   break;	   
		   case "4":
			   giorno = "Mercoledi";
			   break;
		   case "5":
			   giorno = "Giovedi";
			   break;
		   case "6":
			   giorno = "Venerdi";
			   break;
		   case "7":
			   giorno = "Sabato";
			   break;
		}
		return giorno;
	}

}
