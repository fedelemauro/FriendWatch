package Progetto;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Orologio_DigitaleFrame extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5227386601147754982L;
	private JButton buttonRed;
	private JButton buttonGreen;
	private JButton buttonSinistro;
	private JButton buttonGiu;
	private boolean ok;
	private ActionListener pro;
	
	public Orologio_DigitaleFrame() throws IOException {
		buttonGiu = new JButton("Giu");
		pro = new Promemoria();
		buttonGiu.addActionListener(pro);
		buttonSinistro = new JButton("Sinistra");
		ActionListener listener = new BattitoCardiaco();
		buttonSinistro.addActionListener(listener);
		ButtonRed();
		ButtonGreen();
		Thread t=new Thread(new CalcolateOraData());
		SchermataPrincipale();
		t.start();
	}
	
	public void ButtonRed() {
		this.buttonRed = new JButton("    ");
		buttonRed.setBackground(Color.red);
		 class ViewAltopralante  implements ActionListener, Runnable{
			 	public void actionPerformed(ActionEvent event){
			 	Thread t = new Thread(this);
			 	t.start();
			 	}

				@Override
				public void run() {
					
					System.out.println("Stai inviando la richiesta di soccorso al 118...");
					JOptionPane.showMessageDialog(null,"Stiamo inviando un'ambulanza all'ultima posizione!", "118", JOptionPane.INFORMATION_MESSAGE);
				}
		}
		 ActionListener listener = new ViewAltopralante();
		 buttonRed.addActionListener(listener);
	}
	public void ButtonGreen() {
		this.buttonGreen = new JButton("    ");
		buttonGreen.setBackground(Color.green);
		 class ViewAltopralante  implements ActionListener, Runnable{
			 	public void actionPerformed(ActionEvent event){
			 	Thread t = new Thread(this);
			 	t.start();
			 	}

				@Override
				public void run() {
					ok = false;
					Scanner in = new Scanner(System.in);
					System.out.println("Stai inviando la richiesta di aiuto ai contatti presenti in rubrica...");
					JOptionPane.showInputDialog("di cosa hai bisogno? dove sei?");
					JOptionPane.showMessageDialog(null,"Sto arrivando!", "Risposta",JOptionPane.INFORMATION_MESSAGE);
					
					
					}
					
				}
		 ActionListener listener = new ViewAltopralante();
		 buttonGreen.addActionListener(listener);
	}
	
	class BattitoCardiaco implements ActionListener{

		public void actionPerformed(ActionEvent evento) {
			Random rand = new Random(); 
			int b = rand.nextInt(200); 
			String battito = Integer.toString(b);
			if(b>=60 && b<= 100){
				Cancellapanel();
				GraficaBattitoGood(battito);
				JOptionPane.showMessageDialog(null,"Il tuo battito � regolare","Regolare",JOptionPane.INFORMATION_MESSAGE);
			} else {
				Cancellapanel();
				GraficaBattitoBad(battito);
				JOptionPane.showMessageDialog (null,"battito irregolare premi il pulsante rosso!","Attenzione",JOptionPane.WARNING_MESSAGE);
			}
			
		}
		
	}
	class Promemoria implements ActionListener {
		private String nome = null;
		private String ora = null;
		private String minuto = null;
		public void actionPerformed(ActionEvent evento) {
			if(this.nome == null && this.ora == null) {
				this.nome = JOptionPane.showInputDialog(null, "Pronunciare il nome del promemoria");
				this.ora = JOptionPane.showInputDialog(null,"Pronunciare l'ora dell'promemoria");
				try {
				int o = Integer.parseInt(ora);
				}
				catch(Exception NumberFormatException) {
					JOptionPane.showMessageDialog (null,"Devi mettere un ora","Attenzione",JOptionPane.WARNING_MESSAGE);
					this.ora = JOptionPane.showInputDialog(null,"Pronunciare l'ora dell'promemoria");
				}
				this.minuto= JOptionPane.showInputDialog(null,"Pronunciare il minuto dell'promemoria");
				try {
				int m = Integer.parseInt(minuto);
				}catch(Exception NumberFormatException) {
					JOptionPane.showMessageDialog (null,"Devi mettere il mminuto","Attenzione",JOptionPane.WARNING_MESSAGE);
					this.minuto= JOptionPane.showInputDialog(null,"Pronunciare il minuto dell'promemoria");
				}
				Cancellapanel();
				Grafica_Ins_Memo(this.nome, this.ora, this.minuto);
			}else {
				Cancellapanel();
				Grafica_View_Memo(this.nome,this.ora, this.minuto);
			}
			
		}
		
		public void ClearVariables() {
			this.nome = null;
			this.ora = null;
			this.minuto = null;
		}
	}
	
	public void SchermataPrincipale() throws IOException {
		Image img = new ImageIcon("img/SchermataPrincipale.PNG").getImage();
		JPanel position = new JPanel() {
			protected void paintComponent (Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(img, 0, 0,this);
				
			}
		};
		position.setLayout(new BorderLayout());
		JPanel viewData= new CalcolateOraData();
		viewData.setLayout(new BorderLayout());
		JPanel buttonPannel = new JPanel();
		JPanel sinistroPanel = new JPanel();
		buttonPannel.add(buttonSinistro);
		buttonPannel.add(buttonGiu);
		buttonPannel.add(buttonRed);
		buttonPannel.add(buttonGreen);
		buttonPannel.setOpaque(false);
		viewData.setOpaque(false);
		position.add(viewData, BorderLayout.CENTER);	
		position.add(buttonPannel, BorderLayout.SOUTH);
		//position.add(sinistroPanel, BorderLayout.WEST);
		position.setOpaque(false);
		this.add(position);
		this.setBackground(Color.white);
		
	}
	
	public void Cancellapanel() {
		this.getContentPane().removeAll();
		this.repaint();
		
	}
	
	public void Ridisegno() {
		this.validate();
	}
	
	public void GraficaBattitoGood(String battito) {
		Image img = new ImageIcon("img/BattitoGood.PNG").getImage();
		JPanel position = new JPanel() {
			protected void paintComponent (Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(img, 0, 3,this);
				
			}
		};
		position.setLayout(new BorderLayout());
		JLabel bat = new JLabel("Il tuo battito �"+" "+battito);
		Font font = new Font("Arial", Font.BOLD,30);
		bat.setFont(font);
		JPanel pane = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		/*Questi sono tutti JLabel di riempimento per far andare la nostra scritta dove vogliamo*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=3;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=4;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=5;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=6;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=7;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=8;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=10;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=11;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=12;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=13;
		pane.add(new JLabel(" "), c);
		/*qui mettiamo veramente la scritta*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=14;
		pane.add(bat, c);
		pane.setOpaque(false);
		position.add(pane, BorderLayout.CENTER);
		//Ora facciamo i Bottoni
		JPanel bottoni = new JPanel();
		ActionListener l = new Indietro(this);
		JButton indietro = new JButton("<-----");
		indietro.addActionListener(l);
		bottoni.add(indietro);
		bottoni.setOpaque(false);
		position.add(bottoni, BorderLayout.NORTH);
		position.setOpaque(false);
		this.add(position);
		this.setBackground(Color.white);
		this.validate();
	}
	
	public void GraficaBattitoBad(String battito) {
		Image img = new ImageIcon("img/BattitoBad.PNG").getImage();
		JPanel position = new JPanel() {
			protected void paintComponent (Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(img, 0, 0,this);
				
			}
		};
		position.setLayout(new BorderLayout());
		JPanel b = new JPanel();
		JLabel bat = new JLabel("Il tuo battito �"+" "+battito);
		Font font = new Font("Arial", Font.BOLD,30);
		bat.setFont(font);
		JPanel pane = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		/*Questi sono tutti JLabel di riempimento per far andare la nostra scritta dove vogliamo*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=3;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=4;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=5;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=6;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=7;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=8;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=10;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=11;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=12;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=13;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=14;
		pane.add(new JLabel(" "), c);
		/*qui mettiamo veramente la scritta*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=15;
		pane.add(bat, c);
		pane.setOpaque(false);
		position.add(pane, BorderLayout.CENTER);
		//Ora facciamo i Bottoni
		JPanel bottoni = new JPanel();
		JButton buttonRed = new JButton("    ");
		buttonRed.setBackground(Color.red);
		ActionListener listener = new IndietroConAvviso(this);
		buttonRed.addActionListener(listener);
		bottoni.add(buttonRed);
		position.add(bottoni, BorderLayout.SOUTH);
		position.setOpaque(false);
		this.add(position);
		this.setBackground(Color.white);
		this.validate();
	}
	public void Grafica_Ins_Memo(String nome, String ora, String minuto) {
		Image img = new ImageIcon("img/Ins_Memo.PNG").getImage();
		JPanel position = new JPanel() {
			protected void paintComponent (Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(img, 0, 7,this);
				
			}
		};
		position.setLayout(new BorderLayout());
		JLabel proA = new JLabel(nome);
		Font font = new Font("Arial", Font.BOLD,30);
		proA.setFont(font);
		JLabel proB = new JLabel(ora+" : "+minuto);
		proB.setFont(font);
		JPanel pane = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		//utile per spostare la frase
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=3;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=4;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=5;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=6;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=7;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=8;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=9;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=10;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=11;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=12;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=13;
		pane.add(new JLabel(" "), c);
		//Frase utile
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=14;
		pane.add(proA, c);
		//utile per spostare la frase
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=15;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=16;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=17;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=18;
		pane.add(new JLabel(" "), c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=19;
		pane.add(proB, c);
		pane.setOpaque(false);
		position.add(pane, BorderLayout.NORTH);
		position.setOpaque(false);
		this.add(position);
		this.setBackground(Color.white);
		this.validate();
		int choise = JOptionPane.showConfirmDialog(null, "Confermi il Promemoria?");
		if(choise == 0) {
			Cancellapanel();
			Grafica_View_Memo(nome,ora, minuto);
		}else {
			JOptionPane.showMessageDialog(null,"Il promemoria non � stato regidtrsto","Promemoria non Registrato",JOptionPane.INFORMATION_MESSAGE);
			Cancellapanel();
			try {
				Promemoria p = (Promemoria) pro;
				p.ClearVariables();
				SchermataPrincipale();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Ridisegno();
		}
	}
	public void Grafica_View_Memo(String nome, String ora, String minuto) {
		Image img = new ImageIcon("img/View_Memo.PNG").getImage();
		JPanel position = new JPanel() {
			protected void paintComponent (Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(img, 0, 20,this);
				
			}
		};
		position.setLayout(new BorderLayout());
		JLabel proA = new JLabel(nome);
		Font font = new Font("Arial", Font.PLAIN,30);
		proA.setFont(font);
		JLabel proB = new JLabel(ora);
		Font font1 = new Font("Arial", Font.BOLD,100);
		proB.setFont(font1);
		JLabel proC = new JLabel(minuto);
		proC.setFont(font1);
		ActionListener l = new Indietro(this);
		JButton indietro = new JButton("<-----");
		indietro.addActionListener(l);
		JPanel pane = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		//Bottone
		c.gridx=0;
		c.gridy=0;
		pane.add(indietro, c);
		//utile per spostare la frase
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		pane.add(new JLabel(" "), c);
		c.gridx=0;
		c.gridy=2;
		pane.add(new JLabel(" "), c);
		//Frase utile-----------------------------
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=3;
		pane.add(proB, c);
		//Data di oggi-----------------------------------------------------------------
		Calendar cal = new GregorianCalendar();
		String giorno = String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
		int month = cal.get(Calendar.MONTH);
	    String mese = String.valueOf(month);
	    int m = Integer.parseInt(mese)+1;
		String anno = String.valueOf(cal.get(Calendar.YEAR));
		String numeroGiorno = String.valueOf(cal.get(Calendar.DAY_OF_WEEK));
		String nomeGiorno = ConvertNumToString(numeroGiorno);
		JLabel data = new JLabel(nomeGiorno+" "+giorno+"."+m+"."+anno);
		Font font2 = new Font("Arial", Font.PLAIN,30);
		data.setFont(font2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=4;
		pane.add(data, c);   
		//utile per spostare la frase-------------------------------------------------------
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=5;
		pane.add(proC, c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=6;
		pane.add(proA, c);
		pane.setOpaque(false);
		position.add(pane, BorderLayout.NORTH);
		position.setOpaque(false);
		this.add(position);
		this.setBackground(Color.white);
		this.validate();
	}
	private String ConvertNumToString(String numeroGiorno) {
		String giorno = null;
		
		switch(numeroGiorno) {
		   case "1":
			   giorno = "Domenica";
			   break;
		   case "2":
			   giorno = "Lunedi";
			   break;
		   case "3":
			   giorno = "Martedi";
			   break;	   
		   case "4":
			   giorno = "Mercoledi";
			   break;
		   case "5":
			   giorno = "Giovedi";
			   break;
		   case "6":
			   giorno = "Venerdi";
			   break;
		   case "7":
			   giorno = "Sabato";
			   break;
		}
		return giorno;
	}

}
