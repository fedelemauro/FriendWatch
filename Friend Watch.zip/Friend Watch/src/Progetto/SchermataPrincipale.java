package Progetto;
import java.io.IOException;

import javax.swing.JFrame;

public class SchermataPrincipale {

	public static void main(String[] args) throws IOException {
		
		JFrame frame = new Orologio_DigitaleFrame();
		final int FRAME_WIDTH = 460;
		final int FRAME_HEIGHT = 615; 
		frame.setResizable(false);
		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		frame.setTitle("Friend Watch");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true); 
	}

}
