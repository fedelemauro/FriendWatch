package Progetto;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JOptionPane;

public class IndietroConAvviso implements ActionListener {
	private Orologio_DigitaleFrame mioFrame;
public IndietroConAvviso(Orologio_DigitaleFrame frame) {
	this.mioFrame = frame;
}
@Override
public void actionPerformed(ActionEvent e) {
	JOptionPane.showMessageDialog(null,"Stiamo inviando un'ambulanza all'ultima posizione!", "118", JOptionPane.INFORMATION_MESSAGE);
this.mioFrame.Cancellapanel();
try {
	this.mioFrame.SchermataPrincipale();
} catch (IOException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
this.mioFrame.Ridisegno();
}
}